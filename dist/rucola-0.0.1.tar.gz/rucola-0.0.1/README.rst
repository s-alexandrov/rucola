======
rucola
======




.. image:: https://pyup.io/repos/github/s-alexandrov/rucola/shield.svg
     :target: https://pyup.io/repos/github/s-alexandrov/rucola/
     :alt: Updates



This is a simple example package Rucola. You can use.



Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
