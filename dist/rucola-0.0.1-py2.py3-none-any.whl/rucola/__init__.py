"""Top-level package for rucola."""

__author__ = """Sergey Alexandrov"""
__email__ = 's.alexandrov@ngs.ru'
__version__ = '0.0.1'
